# Natália Sens Weise e Matheus Petters Bevilaqua
from flask import Flask, jsonify, make_response, render_template
from flask.globals import request
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import create_access_token
from flask_jwt_extended import JWTManager

app = Flask("__name__")
app.config['SECRET_KEY']='teste'
app.config["JWT_SECRET_KEY"] = "secreto" 
app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///prova.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

jwt = JWTManager(app)
db = SQLAlchemy(app)

class Usuario(db.Model):
    __tablename__ = 'Usuarios'
    idUsuario = db.Column(db.Integer, primary_key=True)
    senha = db.Column(db.String(30))
    nomeUsuario = db.Column(db.String(50))

    def __init__(self,  nome="", tel=""):
        self.idUsuario = None
        self.senha = ""
        self.nomeUsuario = str(nome)

with app.app_context():
    db.create_all()

@app.route('/')
def home():
    return render_template('index.html')
    
@app.route('/usuario', methods=['POST'])
def registrarUsuario():  
    try:
        dados = request.json
        senhaProtegida = generate_password_hash(dados['senha'], method='sha256')

        novoUsuario = Usuario(str(dados['nomeUsuario']))
        novoUsuario.senha = str(senhaProtegida)

        db.session.add(novoUsuario)  
        db.session.commit()    
        
        resposta = {"idUsuario":int(novoUsuario.idUsuario),
                    "nomeUsuario":str(novoUsuario.nomeUsuario),
                    }

        return jsonify(resposta)
    except:
        return make_response("Request has a semantic error", 422)


@app.route('/login', methods=['POST'])  
def login(): 
    try:
        dados = request.json
        nomeUsuario = dados['nomeUsuario']
        senha = dados['senha']

        usuario = Usuario.query.filter_by(nomeUsuario = dados['nomeUsuario']).first()

        if not check_password_hash(usuario.senha, senha):
            return make_response("Login Invalid", 401)

        acesso = create_access_token(identity=nomeUsuario)
        return jsonify(token=acesso)
    except:
        return make_response('Could Not Verify. Login Is Required',  401)
    
app.run()