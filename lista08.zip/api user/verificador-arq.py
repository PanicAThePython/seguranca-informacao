# Natália Sens Weise e Matheus Petters Bevilaqua
import hashlib
path = input('Insira o path: ')
hashTest = input('Insira o hash: ')

# 810D17CAF02CC9752602380140891696455D322D1152014540C684DD7F143CE7

h = hashlib.sha256()
with open(path,'rb') as file:
    chunk = 0
    while chunk != b'':
        chunk = file.read(1024)
        h.update(chunk)
hashFile = h.hexdigest().upper()

print('O arquivo é íntegro? ' + str(hashFile == hashTest))
